//
//  Pin.h
//  WeavedIOPi
//
//  Created by Hunter Heard on 3/22/16.
//  Copyright (c) 2016 Hunter Heard. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Pin : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *highName;
//@property (nonatomic, copy) NSString *lowName;


@property (nonatomic, assign) int type;

@end
