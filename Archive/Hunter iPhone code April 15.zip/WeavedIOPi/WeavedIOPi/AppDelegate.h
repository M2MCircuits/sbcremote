//
//  AppDelegate.h
//  WeavedIOPi
//
//  Created by Hunter Heard on 3/8/16.
//  Copyright (c) 2016 Hunter Heard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
