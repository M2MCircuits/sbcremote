//
//  main.m
//  WeavedIOPi
//
//  Created by Hunter Heard on 3/8/16.
//  Copyright (c) 2016 Hunter Heard. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

#include "stdio.h"

int main(int argc, char * argv[])
{

    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
