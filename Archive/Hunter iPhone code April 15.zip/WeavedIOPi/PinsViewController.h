//
//  PinsViewController.h
//  WeavedIOPi
//
//  Created by Hunter Heard on 3/22/16.
//  Copyright (c) 2016 Hunter Heard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PinsViewController : UITableViewController

@property (nonatomic, strong) NSMutableArray *pins;

@end
