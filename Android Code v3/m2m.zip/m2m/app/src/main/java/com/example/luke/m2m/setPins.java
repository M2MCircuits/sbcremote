package com.example.luke.m2m;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import m2m.app.api.weavedapi;

public class setPins extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_pins);
    }

    public void pressTrue(View view) {
        EditText mEdit   = (EditText)findViewById(R.id.editText);
        String temp =mEdit.getText().toString();

        if(!temp.equals("")) {
            int pin = Integer.parseInt(mEdit.getText().toString());
            try {
                weavedapi WeavedAPI = new weavedapi();
                //WeavedAPI.login(login, pass);
                WeavedAPI.login("siddhesh.singh@utdallas.edu", "newpass2");
                WeavedAPI.setup(false);
                WeavedAPI.setPiCreds(0, "webiopi", "raspberry");
                WeavedAPI.genPiProxy(0);
                WeavedAPI.setupPi(0, false, "");
                WeavedAPI.updatePi(0);
                WeavedAPI.SetPiGPIOPinFunction(0, pin, true, false);
            } catch (Exception e) {
                e.printStackTrace();
                Toast toast = Toast.makeText(getApplicationContext(), "Pin Set Failed", Toast.LENGTH_LONG);
                toast.show();

            }
        }else{
            Toast toast = Toast.makeText(getApplicationContext(), "Please Select a Pin to Set", Toast.LENGTH_LONG);
            toast.show();
        }

    }

    public void pressFalse(View view) {
        EditText mEdit   = (EditText)findViewById(R.id.editText);
        String temp =mEdit.getText().toString();

        if(!temp.equals("")) {
            int pin = Integer.parseInt(mEdit.getText().toString());
            try {
                weavedapi WeavedAPI = new weavedapi();
                //WeavedAPI.login(login, pass);
                WeavedAPI.login("siddhesh.singh@utdallas.edu", "newpass2");
                WeavedAPI.setup(false);
                WeavedAPI.setPiCreds(0, "webiopi", "raspberry");
                WeavedAPI.genPiProxy(0);
                WeavedAPI.setupPi(0, false, "");
                WeavedAPI.updatePi(0);
                WeavedAPI.SetPiGPIOPinFunction(0, pin, false, false);
            } catch (Exception e) {
                e.printStackTrace();
                Toast toast = Toast.makeText(getApplicationContext(), "Pin Set Failed", Toast.LENGTH_LONG);
                toast.show();

            }
        }else{
            Toast toast = Toast.makeText(getApplicationContext(), "Please Select a Pin to Set", Toast.LENGTH_LONG);
            toast.show();
        }
    }
}
